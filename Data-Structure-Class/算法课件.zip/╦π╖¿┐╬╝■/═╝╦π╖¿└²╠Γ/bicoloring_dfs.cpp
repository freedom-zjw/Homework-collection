#include <queue>
#include <vector>
#include <iostream>
#include <cstdio>
#include <cstdlib>
#include <cstring>
using namespace std;
const int MAXN = 1010;
vector<int> graph[MAXN];
int vis[MAXN];   // 0表示未访问，1表示访问过 
int n, m, u, v;
int color[MAXN]; // 0表示未染色，1表示染为红色，-1表示染为黑色 
    
bool dfs(int u) 
{
  for(int i = 0; i< graph[u].size(); i++) {
    int v = graph[u][i];
    if (color[v] == color[u]) return false;
    if (!color[v]) {
      color[v] = -color[u];
      if (!dfs(v)) return false;
    }
  }
  return true;
}     


int main()
{
  memset(vis,0,sizeof(vis));
  memset(color,0,sizeof(color));
  
  cin >> n >> m;
  for (int i=1; i<=m; i++)
  {
    cin >> u >> v;
    graph[u].push_back(v);
    graph[v].push_back(u);     
  }
  color[1]=1;
  cout << (dfs(1) ? "yes" : "no") << endl;  
  return 0;  
}
