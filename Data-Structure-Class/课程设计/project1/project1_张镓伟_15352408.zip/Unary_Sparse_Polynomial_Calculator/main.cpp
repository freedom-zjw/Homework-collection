#include "main_control.h"
int main(int argc, char *argv[]){
	MainControl A;
	A.start_work();
	return 0;
}
