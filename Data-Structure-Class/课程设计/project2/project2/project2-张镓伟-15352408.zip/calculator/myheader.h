#ifndef MYHEADER_H_
#define MYHEADER_H_
#include<iostream>
#include<cstring>
#include<cstdlib>
#include<string>
#include<cstdio>
#include<map>
#include<algorithm>
#define rep(i,u,v) for (int i=(u);i<=(v);i++)
using std::string;
using std::cin;
using std::cout;
using std::endl;
using std::map;
using std::max;
#endif