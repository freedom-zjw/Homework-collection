#include"process.h"
int main(){
    process A;
    A.start();
    return 0; 
}